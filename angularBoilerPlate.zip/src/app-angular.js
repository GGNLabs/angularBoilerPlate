(function () {
    angular
        .module('ggnsModule', ['ngRoute', 'ui.bootstrap', 'util', 'home', 'shared']);

    var routeConfiguration = function ($routeProvider) {
        $routeProvider.when("/", {
            templateUrl: "src/home/view/home.html"
        }).otherwise({
            redirectTo: '/'
        });
    };

    angular.module('ggnsModule').config(routeConfiguration);
})();