(function () {
    'use strict';
    angular.module('shared', ['shared.services']);
})();