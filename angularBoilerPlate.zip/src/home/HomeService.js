(function () {
    angular
        .module('home')
        .service('HomeService', ['$rootScope', HomeService]);

    function HomeService() {
        var self = this;
    };
})();