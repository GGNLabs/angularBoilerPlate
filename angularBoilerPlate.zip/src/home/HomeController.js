(function () {

    angular
        .module('home')
        .controller('HomeController', ['$rootScope', HomeController]);

    function HomeController($rootScope) {
        var self = this;
    };
})();