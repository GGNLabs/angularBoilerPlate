(function () {
    'use strict';
    angular.module('util', ['ngRoute']);

    angular
        .module('util')
        .controller('globalController', ['$rootScope', '$routeParams', '$log', '$q', '$scope', '$window', 'localStorage', 'httpService', globalController]);

    function globalController($rootScope, $routeParams, $log, $q, $scope, $window, localStorage, facebookService, httpService) {
        var self = this;
        var saveToken = function (token) {
            localStorage.setData('accesstoken', accessToken);
        };

    }

})();